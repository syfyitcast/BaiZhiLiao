//
//  XMGTabBar.h
//  BuDeJie

#import <UIKit/UIKit.h>

@interface XMGTabBar : UITabBar

@end
