//
//  XMGRefreshHeader.h
//  BuDeJie
//
//  Created by xiaomage on 16/4/22.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface XMGRefreshHeader : MJRefreshNormalHeader

@end
