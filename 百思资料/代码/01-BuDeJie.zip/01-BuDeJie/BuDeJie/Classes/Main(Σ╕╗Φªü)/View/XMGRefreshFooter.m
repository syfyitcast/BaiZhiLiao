//
//  XMGRefreshFooter.m
//  BuDeJie
//
//  Created by xiaomage on 16/4/22.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGRefreshFooter.h"

@implementation XMGRefreshFooter

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
