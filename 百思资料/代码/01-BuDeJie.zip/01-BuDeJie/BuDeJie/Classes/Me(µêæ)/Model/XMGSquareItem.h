//
//  XMGSquareItem.h
//  BuDeJie
//
//  Created by xiaomage on 16/4/6.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>
// name icon url
@interface XMGSquareItem : NSObject
@property (nonatomic ,strong) NSString *name;
@property (nonatomic ,strong) NSString *icon;
@property (nonatomic ,strong) NSString *url;
@end
