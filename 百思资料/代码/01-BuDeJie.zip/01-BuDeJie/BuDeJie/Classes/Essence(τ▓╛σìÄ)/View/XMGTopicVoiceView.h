//
//  XMGTopicVoiceView.h
//  BuDeJie
//
//  Created by xiaomage on 16/4/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMGTopic;

@interface XMGTopicVoiceView : UIView
/** 帖子模型数据 */
@property (nonatomic, strong) XMGTopic *topic;
@end
