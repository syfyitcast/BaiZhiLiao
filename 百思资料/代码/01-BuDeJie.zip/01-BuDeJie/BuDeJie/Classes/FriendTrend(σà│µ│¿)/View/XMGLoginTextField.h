//
//  XMGLoginTextField.h
//  BuDeJie
//
//  Created by xiaomage on 16/4/6.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMGLoginTextField : UITextField

@end
