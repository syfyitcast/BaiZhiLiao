//
//  XMGSubTagItem.m
//  BuDeJie
//
//  Created by xiaomage on 16/4/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSubTagItem.h"

@implementation XMGSubTagItem

@end
