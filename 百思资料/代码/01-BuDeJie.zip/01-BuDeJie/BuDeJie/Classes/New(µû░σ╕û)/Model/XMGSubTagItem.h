//
//  XMGSubTagItem.h
//  BuDeJie
//
//  Created by xiaomage on 16/4/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>
// (image_list,theme_name,sub_number)
@interface XMGSubTagItem : NSObject

@property (nonatomic ,strong) NSString *image_list;
@property (nonatomic ,strong) NSString *theme_name;
@property (nonatomic ,strong) NSString *sub_number;

@end
